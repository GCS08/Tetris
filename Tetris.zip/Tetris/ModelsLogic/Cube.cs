﻿using Tetris.Models;

namespace Tetris.ModelsLogic
{
    public partial class Cube (double width, double height,
        Color color) : CubeModel(width, height, color)
    {
        
    }
}
