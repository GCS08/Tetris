﻿using Tetris.Models;

namespace Tetris.ModelsLogic
{
    public class Cube (double width, double height,
        Color color) : CubeModel(width, height, color)
    {
        
    }
}
