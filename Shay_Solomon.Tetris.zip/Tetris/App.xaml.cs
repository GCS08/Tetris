﻿using Tetris.ModelsLogic;

namespace Tetris
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
            MainPage = new AppShell();
        }
    }
}
