﻿namespace Tetris.Models
{
    /// <summary>
    /// Provides constant values and static data used throughout the application, including game configuration, shape
    /// definitions, and color settings.
    /// </summary>
    public static class ConstData
    {
        #region Fields
        public const int MinCharacterInUN = 5;
        public const int MinCharacterInPW = 8;
        public const int MinCharacterInEmail = 5;
        public const int ToastFontSize = 14;
        public const int GameGridColumnCount = 10;
        public const int GameGridRowCount = 20;
        public const double GameGridColumnWidth = 18;
        public const double GameGridRowHeight = 18;
        public const double OpGameGridColumnWidth = 10;
        public const double OpGameGridRowHeight = 10;
        public const double BetweenCubesBorderWidth = 1;
        public const int ShapesCount = 10;
        public const int ShapeFallIntervalS = 1;
        public const double PushMovesToFirebaseInterval = 0.5;
        public const double OpShapeFallIntervalS = 0.3;
        public const double ShapeFallIntervalMult = 19 / 20;
        public const double MinFallIntervalS = 0.4;
        public const int DeleteFbDocsIntervalS = 3600;
        public const int TotalGameTimeS = 6;
        public const int GameTimeIntervalS = 1;
        public const long FinishedSignal = 0;
        public const int TimePassedToDeleteFbDocS = 60 * 60 * 5;
        public const int ScorePerLine = 100;
        public const int MinShapesInQueue = 5;

        public static readonly List<bool[,]>[] ShapeRotationState =
            [
                ShapeRotationStates.IShape,
                ShapeRotationStates.iShape,
                ShapeRotationStates.JShape,
                ShapeRotationStates.LShape,
                ShapeRotationStates.ZShape,
                ShapeRotationStates.Z2Shape,
                ShapeRotationStates.oShape,
                ShapeRotationStates.OShape,
                ShapeRotationStates.gShape,
                ShapeRotationStates.XShape
            ];
        public static readonly Color[] colors =
            [
                Colors.Red,
                Colors.Orange,
                Colors.Yellow,
                Colors.Green,
                Colors.Blue,
                Colors.Indigo,
                Colors.Violet,
                Colors.LightBlue
            ];
        #endregion

        /// <summary>
        /// Provides debug-related constants for controlling application behavior during development.
        /// </summary>
        public static class DebugData
        {
            #region Fields
            public const bool StartFallTimer = true;
            #endregion
        }

        /// <summary>
        /// Provides predefined rotation states for various Tetris-like shapes as lists of boolean matrices.
        /// </summary>
        public static class ShapeRotationStates
        {
            #region Fields
            public static readonly List<bool[,]> IShape =
            [
                new bool[,] {
                    { true, true, true, true, true }
                },
                new bool[,] {
                    { true },
                    { true },
                    { true },
                    { true },
                    { true }
                }
            ];
            public static readonly List<bool[,]> iShape =
            [
                new bool[,] {
                    { true, true, true, true }
                },
                new bool[,] {
                    { true },
                    { true },
                    { true },
                    { true }
                }
            ];
            public static readonly List<bool[,]> JShape =
            [
                new bool[,] {
                    { true, false, false },
                    { true, true, true }
                },
                new bool[,] {
                    { true, true },
                    { true, false },
                    { true, false }
                },
                new bool[,] {
                    { true, true, true },
                    { false, false, true }
                },
                new bool[,] {
                    { false, true },
                    { false, true },
                    { true, true }
                }
            ];
            public static readonly List<bool[,]> LShape =
            [
                new bool[,] {
                    { false, false, true },
                    { true, true, true }
                },
                new bool[,] {
                    { true, false },
                    { true, false },
                    { true, true }
                },
                new bool[,] {
                    { true, true, true },
                    { true, false, false }
                },
                new bool[,] {
                    { true, true },
                    { false, true },
                    { false, true }
                }
            ];
            public static readonly List<bool[,]> ZShape =
            [
                new bool[,] {
                    { true, true, false },
                    { false, true, true }
                },
                new bool[,] {
                    { false, true },
                    { true, true },
                    { true, false }
                }
            ];
            public static readonly List<bool[,]> Z2Shape =
            [
                new bool[,] {
                    { false, true, true },
                    { true, true, false }
                },
                new bool[,] {
                    { true, false },
                    { true, true },
                    { false, true }
                }
            ];
            public static readonly List<bool[,]> oShape =
            [
                new bool[,] {
                    { true, true},
                    { true, true }
                }
            ];
            public static readonly List<bool[,]> OShape =
            [
                new bool[,] {
                    { true, true, true},
                    { true, true, true },
                    { true, true, true }
                }
            ];
            public static readonly List<bool[,]> gShape =
            [
                new bool[,] {
                    { false, true, false},
                    { true, true, true },
                },
                new bool[,] {
                    { true, false },
                    { true, true },
                    { true, false }
                },
                new bool[,] {
                    { true, true, true},
                    { false, true, false },
                },
                new bool[,] {
                    { false, true },
                    { true, true },
                    { false, true }
                }
            ];
            public static readonly List<bool[,]> XShape =
            [
                new bool[,] {
                    { true, true, true },
                    { true, true, true }
                },
                new bool[,] {
                    { true, true },
                    { true, true },
                    { true, true }
                }
            ];
            #endregion
        }
    }
}
