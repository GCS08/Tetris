﻿namespace Tetris.Models
{
    /// <summary>
    /// Provides a collection of constant string keys used throughout the application for user data, game settings,
    /// error messages, API endpoints, and other configuration values.
    /// </summary>
    public static class Keys
    {
        public const string UserNameKey = "UserName";
        public const string PasswordKey = "Password";
        public const string EmailKey = "Email";
        public const string TotalLinesKey = "TotalLinesCleared";
        public const string GamesPlayedKey = "GamesPlayed";
        public const string HighestScoreKey = "HighestScore";
        public const string DateJoinedKey = "DateJoined";
        public const string ChangeKey = "Changed";
        public const string ResetKey = "Reset";
        public const string FbApiKey = "AIzaSyA7bPSAvpotJs-gSNvMTmwitXrjD-yed_I";
        public const string FbAppDomainKey = "com.meitar.tetris";
        public const string EmailExistsErrorKey = "EMAIL_EXISTS";
        public const string OperationNotAllowedErrorKey = "OPERATION_NOT_ALLOWED";
        public const string WeakPasswordErrorKey =
            "WEAK_PASSWORD : Password should be at least 6 characters";
        public const string MissingEmailErrorKey = "MISSING_EMAIL";
        public const string MissingPasswordErrorKey = "MISSING_PASSWORD";
        public const string InvalidEmailErrorKey = "INVALID_EMAIL";
        public const string InvalidCredentialsErrorKey = "INVALID_LOGIN_CREDENTIALS";
        public const string UserDisabledErrorKey = "USER_DISABLED";
        public const string ManyAttemptsErrorKey = "TOO_MANY_ATTEMPTS_TRY_LATER";
        public const string VerifyEmailKey = "VERIFY_EMAIL";
        public const string FbPostRequest = 
            "https://identitytoolkit.googleapis.com/v1/accounts:sendOobCode?key=";
        public const string RandomUsernameApiUrl =
            "https://randomuser.me/api/?results=1";
        public const string UsersCollectionName = "users";
        public const string GamesCollectionName = "games";
        public const string CubeColorKey = "CubeColor";
        public const string CreatorNameKey = "CreatorName";
        public const string CurrentPlayersCountKey = "CurrentPlayersCount";
        public const string MaxPlayersCountKey = "MaxPlayersCount";
        public const string IsFullKey = "IsFull";
        public const string IsPublicGameKey = "IsPublicGame";
        public const string ShapeIdKey = "ShapeId";
        public const string ShapeColorKey = "ShapeColor";
        public const string CurrentShapeMapKey = "CurrentShapeMap";
        public const string CurrentShapeMapAndMovesKey = "CurrentShapeMapAndMoves";
        public const string NextShapeMapKey = "NextShapeMap";
        public const string TimeCreatedKey = "TimeCreated";
        public const string MaterialSymbolsFontName = "MaterialSymbols";
        public const string OpenSansRegularFontName = "OpenSansRegular";
        public const string OpenSansSemiboldFontName = "OpenSansSemibold";
        public const string PlayerIdKey = "PlayerId";
        public const string UserIDKey = "userID";
        public const string RedKey = "Red";
        public const string OrangeKey = "Orange";
        public const string YellowKey = "Yellow";
        public const string GreenKey = "Green";
        public const string BlueKey = "Blue";
        public const string IndigoKey = "Indigo";
        public const string VioletKey = "Violet";
        public const string LightBlueKey = "Light Blue";
        public const string TransparentKey = "Transparent";
        public const string PlayerDetailsKey = "PlayerDetails";
        public const string IsPlayerReadyKey = "IsPlayerReady";
        public const string IsShapeAtBottomKey = "IsShapeAtBottom";
        public const string FinalStateKey = "FinalState";
        public const string WaitingRoomKey = "WaitingRoom";
        public const string ReadyKey = "Ready";
        public const string PlayerMoveKey = "PlayerMove";
        public const string PublicKey = "Public";
        public const string PrivateKey = "Private";
        public const string TitleKey = "title";
        public const string MessageKey = "message";
        public const string NotificationChannelId = "default";
        public const string NotificationChannelName = "Default";
        public const string PrivateJoinCodeKey = "PrivateJoinCode";
        public const string X = "X";
        public const string Y = "Y";
        public const string RotationIndex = "RotationIndex";
    }
}
