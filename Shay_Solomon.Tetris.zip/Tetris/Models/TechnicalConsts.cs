﻿namespace Tetris.Models
{
    /// <summary>
    /// Provides constant values used throughout the application, including default strings, file paths, JSON keys, date
    /// formats, and common character symbols.
    /// </summary>
    public class TechnicalConsts
    {
        #region Fields
        public const string DefaultUserName = "Guest";
        public const string ResponseText = "Response:";
        public const string ErrorJson = "error";
        public const string MessageJson = "message";
        public const string MaterialSymbolsFontPath = 
            "MaterialSymbolsOutlined.ttf";
        public const string OpenSansRegular = "OpenSans-Regular.ttf";
        public const string OpenSansSemiBold = "OpenSans-Semibold.ttf";
        public const string lineClearedPath = "Sounds/lineCleared.mp3";
        public const string shapeDownPath = "Sounds/shapeDown.mp3";
        public const string ResultsJson = "results";
        public const string LoginJson = "login";
        public const string UsernameJson = "username";
        public const string DateFormat = "dd/MM/yy";
        public const string ClosingBraceSign = "}";
        public const string ZeroSignString = "0";
        public const string ArrowSignString = "=>";
        public const char AtSign = '@';
        public const char DotSign = '.';
        public const char SlashSign = '/';
        public const char SpaceSign = ' ';
        public const char ZeroSign = '0';
        public const char NineSign = '9';
        public const char ASign = 'a';
        public const char ZSign = 'z';
        public const char CapitalASign = 'A';
        public const char CapitalZSign = 'Z';
        public const char ExclamationSign = '!';
        #endregion
    }
}
